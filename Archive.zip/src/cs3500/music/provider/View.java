package cs3500.music.provider;


public interface View {
  /**
   * Interface class to display the music editor.
   */
  void display(ViewModel model);
}
